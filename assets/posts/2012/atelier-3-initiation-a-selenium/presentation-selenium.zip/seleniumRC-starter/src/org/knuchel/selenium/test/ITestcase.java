package org.knuchel.selenium.test;

public interface ITestcase {
	public void start();
}
