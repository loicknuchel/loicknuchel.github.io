
Getting started :
  - copy the project into your workspace
  - rename it (folder and artifactId in pom.xml)
  - import it into eclipse (new Maven Project)
  - have fun !
