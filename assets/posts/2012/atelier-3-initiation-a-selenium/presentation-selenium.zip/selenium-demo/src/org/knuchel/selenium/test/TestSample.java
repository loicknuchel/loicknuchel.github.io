package org.knuchel.selenium.test;

import org.knuchel.selenium.pages.ComputerListPage;
import org.knuchel.selenium.pages.global.State;

public class TestSample implements ITestcase {

	/**
	 * the test must start on login page and will stop at the same point
	 */
	public void start() {
		State state = State.getInstance();

		ComputerListPage computerListPage = (ComputerListPage) state.getPage();

	}
}
