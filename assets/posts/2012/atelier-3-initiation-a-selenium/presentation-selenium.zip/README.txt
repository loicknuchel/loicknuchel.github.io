
Présentation de Sélénium par Loïc KNUCHEL le 17/10/2012 à Nexeo.

Tous les projets mis en exemple ci-dessous sont des projets eclipse.

  * playsample-computer-database
    C'est le site web sur lequel repose la démonstration de sélénium.
    Pour le mettre en place, il faut télécharger et installer Play! (http://www.playframework.org/download puis http://www.playframework.org/documentation/2.0.3/Installing).
    La version utilisée pour la démo est la 2.0.3.
    Une fois Play! installé, il suffit de taper la commande "play" dans le dossier du projet puis de lancer le serveur avec "run".
    Le site se trouve alors à l'adresse : http://localhost:9000
  
  * selenium-demo
    C'est un projet maven qui contient les tests du site playsample-computer-database.
    Pour pouvoir l'utiliser il faut avoir maven installé.
    Il faut ensuite télécharger le driver chrome (http://code.google.com/p/selenium/wiki/ChromeDriver).
    Le projet doit être configuré avec les url local dans la classe org.knuchel.selenium.config.Config
    Une fois tout installé (server web + projet sélénium), vous pouvez le lancer pour voir ce qu'il donne.
  
  * sélénium IDE
    Sélénium IDE est un ensemble de plugins firefox. Ils sont téléchargeables et installables depuis cette adresse : http://seleniumhq.org/download/
    Il semble qu'il y ait un bug et que le bouton sélénium ne possède pas d'image. Je conseille d'installer en complément le plugin : https://addons.mozilla.org/fr/firefox/addon/selenium-ide-button/
    Pour ajouter le bouton à la barre de navigation : click droit -> personnaliser.
  
  * seleniumIDE-starter et seleniumRC-starter
    Ce sont deux projets vides qui possèdent le nécessaire pour débuter rapidement un projet sélénium. Ils sont mis à jour et téléchargeables ici : https://github.com/loicknuchel/starters
    Le premier (seleniumIDE-starter) met en place les dépendances sélénium nécessaire pour jouer les tests issus de sélénium IDE. Il est donc peu volumineux.
    Le second (seleniumRC-starter) implémente un mini-framework qui permet de faciliter l'utilisation de sélénium. Il est recommandé de l'utiliser si on code soi même les scénarios de test.
    